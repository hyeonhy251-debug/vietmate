# VietMate 3.1

## 포함 기능
- 기존 VietMate 3.0 학습 기록(localStorage) 유지
- 알파벳 29자/성조/모음 조합
- 단어장/검색/퀴즈/복습
- 회화/문장 교정/받아쓰기/오늘의 단어
- 전체 커리큘럼 10단계
- 음성 듣기 + 브라우저 음성 인식 말하기 연습
- 문장 순서 배열 퀴즈
- XP/레벨/배지
- JSON 학습 기록 백업/복원
- 서버를 통한 실제 AI 회화

## 실행
1. Node.js 설치
2. 이 폴더에서 `npm install`
3. 환경 변수 `OPENAI_API_KEY` 설정
4. `npm start`
5. 브라우저에서 `http://localhost:3000` 접속

API 키는 HTML에 넣지 말고 서버 환경 변수로만 설정하세요.

예:
`OPENAI_API_KEY=여기에_키 npm start`

Windows PowerShell:
`$env:OPENAI_API_KEY="여기에_키"; npm start`

모델은 `OPENAI_MODEL` 환경 변수로 바꿀 수 있고, 기본값은 `gpt-6.1-sol`입니다.
