import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: "200kb" }));
app.use(express.static(__dirname));

const client = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(client) });
});

app.post("/api/chat", async (req, res) => {
  if (!client) return res.status(503).json({ error: "OPENAI_API_KEY가 서버에 설정되지 않았어." });

  const { message, scenario, history } = req.body || {};
  if (typeof message !== "string" || !message.trim()) {
    return res.status(400).json({ error: "message가 필요해." });
  }
  const safeHistory = Array.isArray(history) ? history.slice(-10).filter(x =>
    x && (x.role === "user" || x.role === "assistant") && typeof x.content === "string"
  ) : [];

  const system = `너는 VietMate의 베트남어 선생님이다.
학습자는 한국어가 모국어인 완전 초보 학생이다.
목표는 베트남 친구와 자연스럽게 채팅하는 것이다.
상황: ${String(scenario || "자유 회화")}
규칙:
- 기본 답변은 한국어 설명 + 자연스러운 베트남어 예문을 함께 준다.
- 학습자가 베트남어로 말하면 자연스러운 표현인지 짧게 교정한다.
- 초보자가 이해할 수 있게 문법을 아주 쉽게 설명한다.
- 발음은 한국어식 근사 발음을 제공할 수 있지만 그것이 정확한 음성 표기는 아니라고 알려준다.
- 친구 사이 표현과 존댓말/공손한 표현의 차이를 필요할 때 알려준다.
- 위험하거나 부적절한 요청은 도와주지 않는다.
- 개인정보, 비밀번호, 인증코드 등을 요구하지 않는다.
- 답변은 너무 길지 않게 한다.`;

  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6.1-sol",
      instructions: system,
      input: [...safeHistory, { role: "user", content: message.trim() }],
      max_output_tokens: 500
    });
    res.json({ reply: response.output_text || "답변을 만들지 못했어. 다시 시도해 줘." });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "AI 서버에서 답변을 만드는 중 오류가 발생했어." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "vietmate3_1.html")));
app.listen(port, () => console.log(`VietMate running on port ${port}`));
